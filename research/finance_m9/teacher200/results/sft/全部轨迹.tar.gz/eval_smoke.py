"""Paired end-to-end check of the deployed M9 interface on two label-blind VAL fields."""
import csv
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
M9 = ROOT / "research/finance_m9"
sys.path.insert(0, str(M9))
BASE_DIR = Path("/home/zhubh/finance_program_grpo_full_migrated_20261027_r3/dependencies")
BASE = BASE_DIR / "finance_program_5090_smoke_20261010/models/Qwen3.5-9B"
SKILL = Path("/home/zhubh/finance_skill_extractive_sft_20261104_r1/scale01/adapter-final")
PLANNERS = {"student": Path("/home/zhubh/finance_student_teacher200_20261126/planner-adapter"),
            "fresh162": BASE_DIR / "finance_program_student_fresh162_20261022_r5/runs/training/final-adapter"}
CASES = ("1f8e13af-de33-5bcd-8323-8c152e1a6930", "3625bcf3-d615-51f9-8deb-ba90967ba3d6")


def write(path, obj):
    tmp = path.with_suffix(".partial")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2))
    tmp.replace(path)


def evaluate(arm, *, source_ids=None, output=None):
    import episode
    from model import load_backend
    from native_assets import prepare
    from transformers import set_seed
    args = SimpleNamespace(model=BASE, planner=PLANNERS[arm], skill=SKILL)
    set_seed(2026110509)
    public = episode.cohort(M9 / "val422/val422-inputs.json", "VAL")
    cases = {c["source_id"]: c for c in public["inputs"]["cases"]}
    if len(cases) != 422:
        raise ValueError("Need all VAL sources for full table lookups")
    with tempfile.TemporaryDirectory() as tmp:
        episode.install_native(prepare(Path(tmp) / "deps", public["scopes"]))
        backend = load_backend(args)
        original_call = backend.call
        original_env = episode.environment
        for sid in (CASES if source_ids is None else source_ids):
            folder = (ROOT / "runs" if output is None else output) / arm / sid
            folder.mkdir(exist_ok=True, parents=True)
            if (folder / "result.json").is_file():
                continue
            calls = []
            def observe_call(stage, messages, *, sample):
                raw = json.dumps(messages, ensure_ascii=False, separators=(",", ":")).encode()
                event = dict(stage=stage, input_sha256=hashlib.sha256(raw).hexdigest(), start=time.time())
                calls.append(event)
                write(folder / "calls.json", calls)
                reply, action = original_call(stage, messages, sample=sample)
                event.update(end=time.time(), response=reply)
                write(folder / "calls.json", calls)
                return reply, action

            def record_env(*args):
                env = original_env(*args)
                rollout = env.run
                def run(*inner):
                    trace, audit = rollout(*inner)
                    write(folder / "trace.json", trace)
                    return trace, audit
                env.run = run
                return env

            with patch.object(episode, "environment", record_env), patch.object(backend, "call", observe_call):
                try:
                    result, _ = episode.run_episode(public, cases[sid], backend)
                except Exception as err:
                    import traceback
                    write(folder / "error.json", {"exception": repr(err), "traceback": traceback.format_exc()})
                    continue
                write(folder / "result.json", dict(source_id=sid, **result, planner=backend.parent, skill=backend.fixed_skill))


def idle():
    def query(kind, fields):
        text = subprocess.check_output(["nvidia-smi", "--query-" + kind + "=" + fields,
              "--format=csv,noheader,nounits"], text=True, timeout=20)
        return [[c.strip() for c in r] for r in csv.reader(text.splitlines()) if r]
    occupied = {r[0] for r in query("compute-apps", "gpu_uuid")}
    return [u for u, name, total, free, use in query("gpu", "uuid,name,memory.total,memory.free,utilization.gpu")
            if "RTX 6000 Ada" in name and u not in occupied and int(total)-int(free)<1024 and int(use)<=5]


def queued():
    with (ROOT/"pilot.lock").open("a") as owner:
        try:
            fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return
        if (ROOT/"done.json").exists():
            return
        for arm in PLANNERS:
            while True:
                cards = idle()
                write(ROOT/"status.json", dict(phase="waiting_gpu", arm=arm, at=time.time()))
                if not cards:
                    time.sleep(30)
                    continue
                uuid = cards[0]
                with (Path.home()/(".finance-student-sft-"+uuid+".lock")).open("a") as card:
                    try:
                        fcntl.flock(card, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        time.sleep(15)
                        continue
                    if uuid not in idle():
                        continue
                    write(ROOT/"status.json", dict(phase="running", arm=arm, gpu=uuid, at=time.time()))
                    env = dict(os.environ, CUDA_VISIBLE_DEVICES=uuid, PYTHONUNBUFFERED="1")
                    subprocess.run([sys.executable, str(Path(__file__)), arm], check=True, env=env,
                                   pass_fds=(owner.fileno(),card.fileno()))
                    break
        outcomes = {arm: sum((ROOT/"runs"/arm/s/"result.json").is_file() for s in CASES) for arm in PLANNERS}
        write(ROOT/"done.json", dict(outcomes=outcomes, at=time.time()))
        write(ROOT/"status.json", dict(phase="finished", outcomes=outcomes, at=time.time()))


if __name__=="__main__":
    if sys.argv[1:] == ["queue"]:
        queued()
    else:
        evaluate(sys.argv[1])
